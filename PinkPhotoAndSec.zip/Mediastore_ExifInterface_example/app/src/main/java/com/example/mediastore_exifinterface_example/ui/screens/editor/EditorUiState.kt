package com.example.mediastore_exifinterface_example.ui.screens.editor

data class EditorUiState(
    val date: String? = "",
    val latitude: String? = "",
    val longitude: String? = "",
    val phoneName: String? = "",
    val phoneModel: String? = "",
)