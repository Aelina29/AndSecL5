package com.example.mediastore_exifinterface_example.ui.screens.editor

import android.app.Application
import android.content.ContentResolver
import android.net.Uri
import android.widget.Toast
import androidx.exifinterface.media.ExifInterface
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.mediastore_exifinterface_example.domain.use_cases.ValidatorUseCase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class EditorViewModel(val aplication: Application) : AndroidViewModel(aplication) {
    private val _uiState: MutableStateFlow<EditorUiState> = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    private val _errorSF: MutableSharedFlow<String?> = MutableSharedFlow()
    val errorSF: SharedFlow<String?> = _errorSF.asSharedFlow()
    var showError = false

    private val _navigateToPictureScreen = MutableStateFlow(false)
    val navigateToPictureScreen: Flow<Boolean>
        get() = _navigateToPictureScreen

    private lateinit var uri: Uri

    fun onDateChange(newValue: String) {
        _uiState.value = _uiState.value.copy(date = newValue)
    }

    fun onLatitudeChange(newValue: String) {
        _uiState.value = _uiState.value.copy(latitude = newValue)
    }

    fun onLongitudeChange(newValue: String) {
        _uiState.value = _uiState.value.copy(longitude = newValue)
    }

    fun onPhoneNameChange(newValue: String) {
        _uiState.value = _uiState.value.copy(phoneName = newValue)
    }

    fun onPhoneModelChange(newValue: String) {
        _uiState.value = _uiState.value.copy(phoneModel = newValue)
    }

    fun initUiState(
        uri: Uri,
        date: String?,
        latitude: String?,
        longitude: String?,
        phoneName: String?,
        phoneModel: String?
    ) {
        this.uri = uri
        _uiState.value =
            EditorUiState(
                date,
                latitude?.split("/")?.get(0) ?:"",
                longitude?.split("/")?.get(0) ?:"",
                phoneName,
                phoneModel
            )
    }

    private fun validateFields(): Boolean {
        val validator = ValidatorUseCase()
        val nameRes = validator.validateName(_uiState.value.phoneName)
        if (nameRes != null) {
            showError = true
            viewModelScope.launch {
                _errorSF.emit(nameRes)
            }
            return false
        }
        val modelRes = validator.validateModel(_uiState.value.phoneModel)
        if (modelRes != null) {
            showError = true
            viewModelScope.launch {
                _errorSF.emit(modelRes)
            }
            return false
        }
        val locRes =
            validator.validateLocation(_uiState.value.longitude, _uiState.value.latitude)
        if (locRes != null) {
            showError = true
            viewModelScope.launch {
                _errorSF.emit(locRes)
            }
            return false
        }
        return true
    }

    fun saveTags(contentResolver: ContentResolver) {
        if (_uiState.value.date.isNullOrBlank()
            || _uiState.value.phoneName.isNullOrBlank()
            || _uiState.value.phoneModel.isNullOrBlank()
            || _uiState.value.latitude.isNullOrBlank()
            || _uiState.value.longitude.isNullOrBlank()
        ) {
            Toast.makeText(aplication, "Все поля должны быть заполнены", Toast.LENGTH_SHORT).show()
            return
        }
        if (!validateFields()) return
        contentResolver.openFileDescriptor(uri, "rw", null)
            ?.use { fileDescriptor ->
                val exif = ExifInterface(fileDescriptor.fileDescriptor)

                val date = _uiState.value.date
                exif.setAttribute(ExifInterface.TAG_DATETIME, date)

                val name = _uiState.value.phoneName
                exif.setAttribute(ExifInterface.TAG_MAKE, name)

                val model = _uiState.value.phoneModel
                exif.setAttribute(ExifInterface.TAG_MODEL, model)

                val lat = _uiState.value.latitude
                val lon = _uiState.value.longitude
                exif.setLatLong(lat!!.toDouble(), lon!!.toDouble())

                exif.saveAttributes()
            }
        _navigateToPictureScreen.value = true
    }
}