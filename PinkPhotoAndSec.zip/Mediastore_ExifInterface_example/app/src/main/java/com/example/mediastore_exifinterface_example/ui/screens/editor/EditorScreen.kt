package com.example.mediastore_exifinterface_example.ui.screens.editor

import android.content.Context
import android.content.ContextWrapper
import android.content.res.Configuration
import android.media.ExifInterface
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.mediastore_exifinterface_example.ui.composable.BasicCustomTextField
import com.google.android.material.datepicker.MaterialDatePicker

@Composable
fun EditorScreen(
    vm: EditorViewModel = viewModel(),
    uri: Uri,
    navController: NavHostController
) {
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current

    LaunchedEffect(Unit) {
        val contentResolver = context.contentResolver
        contentResolver.openFileDescriptor(uri, "w", null)
            ?.use { fileDescriptor ->
                val exif = androidx.exifinterface.media.ExifInterface(fileDescriptor.fileDescriptor)
                val date = exif.getAttribute(ExifInterface.TAG_DATETIME)
                val latitude = exif.getAttribute(ExifInterface.TAG_GPS_LATITUDE)
                val longitude = exif.getAttribute(ExifInterface.TAG_GPS_LONGITUDE)
                val phoneModel = exif.getAttribute(ExifInterface.TAG_MODEL)
                val phoneName = exif.getAttribute(ExifInterface.TAG_MAKE)
                vm.initUiState(uri, date, latitude, longitude, phoneName, phoneModel)
            }
    }
    LaunchedEffect(Unit) {
        vm.navigateToPictureScreen.collect { navigate ->
            if (navigate) {
                navController.popBackStack()
            }
        }
    }
    LaunchedEffect(Unit) {
        vm.errorSF.collect { error ->
            if (!vm.showError || error == null) return@collect
            Log.i("kpop", error)
            Toast.makeText(context, error, Toast.LENGTH_SHORT).show()
        }
    }

    val uiState by vm.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .fillMaxWidth()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),

        ) {
        BasicCustomTextField(value = uiState.date ?: "",
            label = "Дата",
            onValueChange = { vm.onDateChange(it) })


        BasicCustomTextField(value = uiState.phoneName ?: "",
            label = "Устройство",
            onValueChange = { vm.onPhoneNameChange(it) })


        BasicCustomTextField(value = uiState.phoneModel ?: "",
            label = "Модель",
            onValueChange = { vm.onPhoneModelChange(it) })



        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            BasicCustomTextField(
                value = uiState.latitude ?: "",
                label = "Широта",
                onValueChange = { vm.onLatitudeChange(it) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
            BasicCustomTextField(
                value = uiState.longitude ?: "",
                label = "Долгота",
                onValueChange = { vm.onLongitudeChange(it) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        }
        Button(
            colors = ButtonDefaults.buttonColors( containerColor = Color.Magenta),
            onClick = {
                keyboardController?.hide()
                vm.saveTags(context.contentResolver)
            }
        ) {
            Text(text = "Сохранить")
        }
    }
}

private fun showDatePicker(activity: FragmentActivity) {
    val picker = MaterialDatePicker.Builder.datePicker().build()
    activity.let {
        picker.show(it.supportFragmentManager, picker.toString())
        picker.addOnPositiveButtonClickListener {

        }
    }
}

fun Context.getActivity(): ComponentActivity? = when (this) {
    is ComponentActivity -> this
    is ContextWrapper -> baseContext.getActivity()
    else -> null
}